<!DOCTYPE HTML>
<html>

<head>
<meta charset = UTF-8 />
<title> Staff </title>
<link rel="stylesheet" type="text/css" href="mycss.css" >
</head>


<body>
<div ID = banner class = main>
<h1> Aston Animal Sanctuary </h1>
</div>


<nav>
<ul class >
    <li> <a href = "staffhome.html"> Home</a></li>
    <li> <a href = "staffanimallist.php"> Animal List</a></li>
    <li> <a href = "addanimal.php"> Add Animal </a></li>
	<li> <a href = "adoption.php"> Adoption Request </a></li>
  <li> <a href = "logout.php"> Logout </a></li>
    
</ul>
</nav>

  <div id="loggedin">
<h2> Logged in as : <p style= color:red> Staff </p> </h2>
    </h2>

  <h3> Available Adoptions <h3>
    

  <?php
try{
			
?>

<table cellspacing="5"  cellpadding="10">
	<tr> <th >AnimalID</th> <th>Name</th> <th >Available</th> <th >UserID</th> <th >Username</th></tr>
  
  
  <?php

	
  // joint query
		$animalist = "SELECT AnimalID,Name,Available,UserID,Username FROM Animal,User";
		$rows=$db->query($animalist);


        //loop through all the returned records and put them into the table cells 
		foreach ($rows as $row) { 
			echo "<tr> <td >" . $row['AnimalID'] . "</td><td >". '<a href="registration.php">'.$row['Name']. '</a>'. "</td><td >" . $row['Available'];
			echo "</td><td >" . $row['UserID']. "</td><td >" . $row['Username'] ."</td></tr> \n";
          
		}

		echo "</table> <br/>";

</body>



</html>

