<html>

<head>
<meta charset = UTF-8 />
<title> Aston Animal Sanctuary </title>
<link rel="stylesheet" type="text/css" href="mycss.css" >
</head>


<body>
  
  <?php
require_once("connectdb.php");
?>
<div ID = banner class = main>
<h1> Animal List </h1>
</div>


<nav>
<ul class >
 <li> <a href = "staffhome.html"> Home</a></li>
    <li> <a href = "animallist.php"> Animal List</a></li>
    <li> <a href = "addanimal.php"> Add Animal </a></li>
	<li> <a href = "adoption.php"> Adoption Request </a></li>
  <li> <a href = "logout.php"> Logout </a></li>
    
</ul>
</nav>

  <?php
try{
			
?>

<table cellspacing="5"  cellpadding="10">
	<tr> <th >AnimalID</th> <th>Name</th> <th >Available</th> <th >UserID</th> <th >Username</th></tr>
  
  
  <?php

	
  // joint query
		$animalist = "SELECT AnimalID,Name,Available,UserID,Username FROM Animal,User GROUP BY AnimalID";
		$rows=$db->query($animalist);


        //loop through all the returned records and put them into the table cells 
		foreach ($rows as $row) { 
			echo "<tr> <td >" . $row['AnimalID'] . "</td><td >". '<a href="registration.php">'.$row['Name']. '</a>'. "</td><td >" . $row['Available'];
			echo "</td><td >" . $row['UserID']. "</td><td >" . $row['Username'] ."</td></tr> \n";
          
		}

		echo "</table> <br/>";
	
} catch (PDOException $ex){
			//this catches the exception when it is thrown
			echo "Sorry, a database error occurred. Please try again.<br> ";
			echo "Error details:". $ex->getMessage();
		}

        
        
        
        
        
?>
  
 





</body>



</html>

