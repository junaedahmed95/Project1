<!DOCTYPE html>
<html>
<head>
  <title>Lab 3 tasks</title>
</head>

<body>
	<h1>Lab 3 tasks</h1>
	<!-- Task 1: Favorite Artists (Arrays) -->
	<!-- write your solution to Task 1 here -->
	
	
	<?php
	
	$artist = array ("Britney Spears", "Christina Aguilera" , "Justin Bieber");
	$artist[] = "Lady Gaga";
	
	
	
	foreach ($artist as $index=>$name){
	
	
		print " $index: $name <br/> \n";
	
	}
	
	?>
	
		
	<div class="section">
		<h2>Task 1: My Favourite Artists using Array</h2>
		
	
	</div>
		
	<!-- Task 2: using functions -->
	<!-- write your solution to Task 2 here -->
	
	<?php
	function daysInMonth ($numb) {
		
		for ($i =1 ; $i<12; $i++){
			
			if ($numb = 1 OR $numb = 3 OR $numb = 5 OR $numb = 7 OR $numb = 8 OR $numb = 10 OR $numb = 12 ){
		print "Month $i => 31 days  <br / > \n ";
		
		}
		
		elseif ($numb = 2   ){
			print "Month $i => 28 days  <br / > \n ";
		}
		
		elseif ($numb = 4  OR $numb= 6 OR $numb = 9 OR $numb = 11){
			print " Month $i => 30 days  <br / > \n ";
		}
		
		}
			
		return $numb;
	
		
		
	}
	daysInMonth(1);
	
	?>

	<div class="section">
		<h2>Task 2: Displaying using functions</h2>
        
		

	</div>
	
	<?php
	include ("footer.php");
	?>
	
	<!-- Task 4 : array of images -->
	<!-- write your solution to Task 4 here -->
	<div class="section">
		<h2>Task 4 : array with images</h2>

		<?php
		
			
			$images = array("building","flower","plane");
			
			rand();
			if (rand() = 1 ) {
				print "$images>=1 <br /> \n";
			<img src="image file" alt="building.jpg" width="20%">;
			
			imagejpeg($images,NULL,20);
			}
			
			
		?>		


		</div>
	
	<!-- Task 5: Favorite Artists from a File (Files) -->
	<!-- write your solution to Task 5 here -->
	<div class="section">
		<h2>Task 5: My Favorite Artists from a file</h2>
		
		
		
		
	</div>
	<!-- Task 6: File operations -->
	<!-- write your solution to Task 6 here -->
	<div class="section">
		<h2>Task 6 : File operations</h2>
		
		
	</div>
	<!-- Task 7: Directory operations -->
	<!-- write your solution to Task 7 here -->
	<div class="section">
		<h2>Task 7 : Directory operations</h2>
		

		
	</div>
	<!-- Task 7 optional: Directory operations -->
	<!-- write your solution to Task 7 optional here -->
	<div class="section">
		<h2>Task 7 optional: Directory operations </h2>



	</div>
	<!-- Task 8: Function for calculation -->
	<!-- write your solution to Task 8 here -->
	<div class="section">
		<h2>Task 8 : Function for calculation </h2>
		
		
		
	</div>
	
	
	<!-- Task 3: including external files -->
	<!-- write your solution to Task 3 here -->
	<div class="section">
		<h2>Task 3: including external files</h2>
	
	
	</div>

</body>
</html>
