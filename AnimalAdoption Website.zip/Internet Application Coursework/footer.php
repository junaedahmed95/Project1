<!DOCTYPE html>
<html>
<head>
  <title>footer.php</title>
</head>

<body>
	<p>
	
	<?php
	
	print "© 2016 Aston University, Aston triangle, Birmingham, B4 7ET +44 (0) 121 204 3000";
	
	?>
	
	
	</p>
</body>
</html>
