<!DOCTYPE HTML >

<html>

<head>
	<title> Login </title>
	<meta charset="UTF-8">
</head>

<body>
<?php

if (isset($_POST["submitted"])){
      
	$errors=array();
	require_once("connectdb.php");	
  
	if (!empty($_POST['username']))
		$username = $_POST['username'];
	else{
		$errors[]= "Please check the 'Username' Field is Filled in <br>";
	}
	if (!empty ($_POST['firstname']))
		$firstname = $_POST['firstname'];	
	else{
		$errors[]= "Please check the 'First Name' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['surname']))
		$surname = $_POST['surname'];	
	else{
		$errors[]= "Please check the 'Surname' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['psw']))
		$pw = $_POST['psw'];
	else{
		$errors[]= "Please check the 'Password' Field is Filled in <br>";
	}
	
	if (!empty ($_POST['cpsw']))
		$cpw = $_POST['cpsw'];
	else{
		$errors[]= "Please check the 'Confirm Password' Field is Filled in <br>";
	}
	
	if ($pw != $cpw){
		$errors[]=  "Your passwords do not match <br>";
    }
  
    $staff = isset($_POST['staff']) ?  'Y' : 'N';
    echo $check;
   
  
  
 
$checkusername = $db->quote($_POST["username"]); 
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $query = $db->query("SELECT Username FROM User WHERE Username= $checkusername");
  
 


  
  
  if (!empty($errors)){

		echo "<h2> Errors with form submission: </h2> \n <ul> " ;
		foreach ($errors as $e){
			echo "<li class = errors> $e </li>";
        }
		echo "</ul>";
  
	} 
  else {
	echo "<h2 class = correct style = color:green; >Login Successful!</h2> \n" ;
	}
	}
	
<div ID = banner class = main>
<h1> Login </h1>
<link rel="stylesheet" type="text/css" href="mycss.css" >
</div>


<nav>
<ul class >
    <li> <a href = "Home.html"> Home</a></li>
    <li> <a href = "login.php"> Login</a></li>
    <li> <a href = "registerform.html"> Register </a></li>
    <li> <a href = "#"> About</a></li>
</ul>
</nav>

<form method = "POST" action = login.php>


Username:  
<input type = "text" name = "firstname"  /> <br />


Password: 
<input type = "password" name = "psw"  /> <br />

<input type = "submit" value = "Submit "/>
<input type = "hidden" name = "submitted" value= "true" /> 

</form>




</body>












</html>