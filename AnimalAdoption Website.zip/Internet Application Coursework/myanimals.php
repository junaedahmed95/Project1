<html>

<head>
<meta charset = UTF-8 />
<title> Aston Animal Sanctuary </title>
<link rel="stylesheet" type="text/css" href="mycss.css" >
</head>


<body>
  
  <?php
require_once("connectdb.php");
?>
<div ID = banner class = main>
<h1> Animal List </h1>
</div>


<nav>
<ul class >
 <li> <a href = "userhome.html"> Home</a></li>
    <li> <a href = "useranimallist.php"> Animal List</a></li>
    <li> <a href = "myanimals.php"> My Animals </a></li>
	<li> <a href = "useradoptionrequest.php"> Adoption Request </a></li>
  <li> <a href = "logout.php"> Logout </a></li>
    
</ul>
</nav>

  <?php
try{
			
?>

<table cellspacing="5"  cellpadding="10">
	<tr> <th >AnimalID</th> <th>Name</th> <th >Available</th></tr>
  
  
  <?php

	
  // joint query
		$animalist = "SELECT AnimalID,Name,Available FROM Animal WHERE Available='Y'";
		$rows=$db->query($animalist);


        //loop through all the returned records and put them into the table cells 
		foreach ($rows as $row) { 
			echo "<tr> <td >" . $row['AnimalID'] . "</td><td >". '<a href="registration.php">'.$row['Name']. '</a>'. "</td><td >" . $row['Available']."</td></tr> \n";
		
          
		}

		echo "</table> <br/>";
	
} catch (PDOException $ex){
			//this catches the exception when it is thrown
			echo "Sorry, a database error occurred. Please try again.<br> ";
			echo "Error details:". $ex->getMessage();
		}

        
        
        
        
        
?>
  
 





</body>



</html>

