<html>
  
<head>

<meta charset = UTF-8 />
<link rel="stylesheet" type="text/css" href="mycss.css" >
<title>Register Form</title>

</head>

<body>
<?php

if (isset($_POST["submitted"])){
  
	$errors=array();
	require_once("registration.php");	
  
	if (!empty($_POST['username']))
		$username = $_POST['username'];
	else{
		$errors[]= "Please check the 'Username' Field is Filled in <br>";
	}
	if (!empty ($_POST['firstname']))
		$firstname = $_POST['firstname'];	
	else{
		$errors[]= "Please check the 'First Name' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['surname']))
		$surname = $_POST['surname'];	
	else{
		$errors[]= "Please check the 'Surname' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['psw']))
		$pw = $_POST['psw'];
	else{
		$errors[]= "Please check the 'Password' Field is Filled in <br>";
	}
	
	if (!empty ($_POST['cpsw']))
		$cpw = $_POST['cpsw'];
	else{
		$errors[]= "Please check the 'Confirm Password' Field is Filled in <br>";
	}
	
	if ($pw != $cpw){
		$errors[]=  "Your passwords do not match <br>";
    }
  
  if (!empty($errors)){
		echo "<h2> Errors with form submission: </h2> \n <ul>";
		foreach ($errors as $e){
			echo "<li> $e </li>";
        }
		echo "</ul>";
  
	} else {
	
 try{
			// use the form data to create a insert SQL and  add a student record  
			$sth=$db->prepare("INSERT INTO USer (UserID, Staff, Password) VALUES (?,?,?,?,?,?)");
			$sth->execute(array($firstname,$surname,$psw));
			echo " Well Done, you just add one student record! <br><br>"; 
	?>
		<!-- HTML table to  display  all the student records -->
		<table cellspacing="0"  cellpadding="5">
		<tr><th>UserID</th> <th >Staff</th> <th >Password</th> <th >Surname</th><th >Gender</th><th >Year</th><th >Photo</th></tr>
	<?php
			// Use select to get all student records and output in a table 
			$rows=$db->query("select * from User");
			foreach ($rows as $row) { 
				echo  "<tr><td >" . $row['UserID'] . "</td><td >" . $row['Staff'] . "</td><td >" . $row['first_name'];
				echo "</td><td >" . $row['last_name'] . "</td><td >" . $row['gender']. "</td><td >" . $row['year_enroll']."</td><td ><img src=". $row['photo']." alt='Smiley face' height='50' width='50'></td></tr>\n";
			}
			echo "</table> <br>";
			
		} catch (PDOException $ex){
			//this catches the exception when it is thrown
			echo "Sorry, a database error occurred. Please try again.<br> ";
			echo "Error details:". $ex->getMessage();
		}
	}
} else {
?>


  
<div ID = banner class = main>
<h1> Aston Animal Sanctuary </h1>
</div>

          
          
          
	<div>

<nav>
<ul class >
    <li> <a href = "home.html"> Home</a></li>
    <li> <a href = "loginform.html"> Login</a></li>
    <li> <a href = "registration.php"> Register </a></li>
    <li> <a href = "#"> About</a></li>
</ul>
</nav>
</div>
          
          

<h1> Register Form </h1>

  

<form action = "registration.php" method = "post" >


Username:  
<input type = "text" name = "username"  /> <br />


First Name:  
<input type = "text" name = "firstname"  /> <br />
  
Surname:  
<input type = "text" name = "surname"  /> <br />  
  
Password: 
<input type = "password" name = "psw"  /> <br />


Confirm Password: 
<input type = "password" name = "cpsw"  /> <br/>
 
Select Gender: 
<label> Male </label>
<input type = "radio" name = "gender" value= "Male" /> 
<label> Female </label>
<input type = "radio" name = "gender" value= "Female" /> 
<br/>

Date Of Birth: 
<input type = "date" name = "Dob" min= "2000-01-02" /> <br />


<input type = "submit" name = "submit" value = "Submit"/>
<input type = "hidden" name = "submitted" value= "true" /> 
<input type="reset" value="Clear" />


</form>

<?php }
?>
          
          </body>
  </html>
  
	