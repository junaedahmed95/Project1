<html>
  
<head>

<meta charset = UTF-8 />
<link rel="stylesheet" type="text/css" href="mycss.css" >
<title>Adoption Form</title>

</head>

<body>
  
<div ID = banner class = main>
<h1> Aston Animal Sanctuary </h1>
</div>

          
          
          
	<div>

<nav>
<ul class >
    <li> <a href = "userhome.html"> Home</a></li>
    <li> <a href = "useranimallist.php"> Animal List</a></li>
    <li> <a href = "myanimals.php"> My Animals </a></li>
	<li> <a href = "useradoptionrequest.php"> Adoption Request </a></li>
  <li> <a href = "logout.php"> Logout </a></li>
  
</ul>
</nav>
</div>
         
<?php

if (isset($_POST["submitted"])){
      
	$errors=array();
	require_once("connectdb.php");	
  
	if (!empty($_POST['dropdown']))
		$username = $_POST['dropdown'];
	else{
		$errors[]= "Please check the 'ID' Field is Filled in <br>";
	}
	



  $animalquery=$db->query("SELECT Name FROM Animal");
  
  
  // $data = $query->fetchAll(PDO::FETCH_ASSOC);
  

//echo "<select name=dropdown value=''>AnimalID</option>"; // list box select command
     
  //foreach ($db->query($animalquery) as $row){ //Array or records stored in $row

//echo "<option value=$row[AnimalID]</option>"; 

///* Option values are added by looping through the array */ 

//}
  
// echo "</select>"; // Closing of list box

  
  // }

 
//echo "<select name='dropdown'>";
//while ($row =fetch($query)) {
  //  echo "<option value='" . $row['AnimalID'] ."'>" . $row['Name'] ."</option>";
//}
//echo "</select>";
  



/*<?php foreach ($data as $row): ?>
  //  <option><?=$row["AnimalID"]?></option>
  	<?php endforeach ?>
*/
  
  
  if (!empty($errors)){

		echo "<h2> Errors with form submission: </h2> \n <ul> " ;
		foreach ($errors as $e){
			echo "<li class = errors style=color:red > $e </li>";
        }
		echo "</ul>";
  
	} 
  else {
	echo "<h2 class = correct style = color:green; >Registration Successful!</h2> \n" ;
    
 try{
  

 
	?>
		
	<?php
			
			  
		} catch (PDOException $ex){
			//this catches the exception when it is thrown
			
			echo "Sorry, a database error occurred. Please try again.<br> ";
   			
		}
    
    
	}
} 
?>
    
 

 
          

<h1> Adoption Request Form </h1>


    <p>
  <?php foreach($animalquery->fetchAll() as $row):  ?>
    <?php echo  $row['Name']; ?>
    <?php endforeach; ?>
  </p>
          
      <div ID = "form">    
<form action = "useradoptionrequest.php" method = "post"  >

  <label> ID Of Animal </label>
  <br/>
 
<select name="dropdown">
 


</select>
 
    

  <label>
<input type = "submit" name = "submit" value = "Submit"/>
<input type = "hidden" name = "submitted" value= "true" /> 
<input type="reset" value="Clear" />
  </label>
</form>
          </div>


          
          </body>
  </html>
  
	