<html>
  
<head>

<meta charset = UTF-8 />
<link rel="stylesheet" type="text/css" href="mycss.css" >
<title>Register Form</title>

</head>

<body>
  
<div ID = banner class = main>
<h1> Aston Animal Sanctuary </h1>
</div>

          
          
          
	<div>

<nav>
<ul class >
    <li> <a href = "Home.html"> Home</a></li>
    <li> <a href = "login.php"> Login</a></li>
    <li> <a href = "registration.php"> Register </a></li>
  
</ul>
</nav>
</div>
         
<?php

if (isset($_POST["submitted"])){
      
	$errors=array();
	require_once("connectdb.php");	
  
	if (!empty($_POST['username']))
		$username = $_POST['username'];
	else{
		$errors[]= "Please check the 'Username' Field is Filled in <br>";
	}
	if (!empty ($_POST['firstname']))
		$firstname = $_POST['firstname'];	
	else{
		$errors[]= "Please check the 'First Name' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['surname']))
		$surname = $_POST['surname'];	
	else{
		$errors[]= "Please check the 'Surname' Field is Filled in  <br>";
	}
	
	if (!empty ($_POST['psw']))
		$pw = md5($_POST['psw']);
  
  	
	else{
		$errors[]= "Please check the 'Password' Field is Filled in <br>";
	}
	
	if (!empty ($_POST['cpsw']))
  		$cpw = md5($_POST['cpsw']);
  	
	else{
		$errors[]= "Please check the 'Confirm Password' Field is Filled in <br>";
	}
	
	if ($pw != $cpw){
		$errors[]=  "Your passwords do not match <br>";
    }
  
    $staff = isset($_POST['staff']) ?  'Y' : 'N';
    echo $check;
   

  
 
$checkusername = $db->quote($_POST['username']); 

   $query = $db->query("SELECT Username FROM User WHERE Username = $checkusername");
  
   $num_rows = $query->rowCount();

if($num_rows>0)
{

    $errors[]= "Username Already Exists. Please Enter Another Username";
}




  
  
  if (!empty($errors)){

		echo "<h2> Errors with form submission: </h2> \n <ul> " ;
		foreach ($errors as $e){
			echo "<li class = errors style=color:red > $e </li>";
        }
		echo "</ul>";
  
	} 
  else {
	echo "<h2 class = correct style = color:green; >Registration Successful!</h2> \n" ;
    header("Location:userhome.html");
 try{
  

 
			// use the form data to create a insert SQL and  add a user record  
			$sth=$db->prepare("INSERT INTO User (UserID, Staff, Password,Username,First_Name,Surname) VALUES (?,?,?,?,?,?)");
			$sth->execute(array('0',$staff,$pw,$username,$firstname,$surname));
			echo "<p class = correct style = color:green; > You have Successfully Registered an Account!</p> <br><br>"; 
	?>
		
	<?php
			
			  
		} catch (PDOException $ex){
			//this catches the exception when it is thrown
			
			echo "Sorry, a database error occurred. Please try again.<br> ";
   			
		}
    
    
	}
} 
?>
    


 
          

<h1> Register Form </h1>
 
 
  
          
      <div ID = "form">    
<form action = "registration.php" method = "post"  >

        
<label>
Username:  
<input type = "text" name = "username"  /> <br />
  </label>

<label>  
First Name:  
<input type = "text" name = "firstname"  /> <br />
  </label>  
  
<label>  
Surname:  
<input type = "text" name = "surname"  /> <br />  
  </label>
  
<label>  
Password: 
<input type = "password" name = "psw"  /> <br />
  </label>

<label>  
Confirm Password: 
<input type = "password" name = "cpsw"  /> <br/>
  </label> 
  
<label>  
Staff Member? (tick box if 'Yes')
  <br/>
    <input type="checkbox" name="staff" value="Y" />
  </label>
  


  <label>
<input type = "submit" name = "submit" value = "Submit"/>
<input type = "hidden" name = "submitted" value= "true" /> 
<input type="reset" value="Clear" />
  </label>
</form>
          </div>

		  

          
          </body>
  </html>
  
	