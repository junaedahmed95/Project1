<?php
session_start();
?>
<html>

<head>
<meta charset = UTF-8 />
<title> Aston Animal Sanctuary </title>
<link rel="stylesheet" type="text/css" href="mycss.css" >
</head>


<body>
<div ID = banner class = main>
<h1> Aston Animal Sanctuary </h1>
</div>


<nav>
<ul class >
    <li> <a href = "userhome.html"> Home</a></li>
    <li> <a href = "useranimallist.php"> Animal List</a></li>
    <li> <a href = "myanimals.php"> My Animals </a></li>
	<li> <a href = "useradoptionrequest.php"> Adoption Request </a></li>
  <li> <a href = "logout.php"> Logout </a></li>
    
</ul>
</nav>

<h2> Logged in as : <p style= color:red> User </p> </h2>

  <h3> My Animals </h3>

  
  <?php
try{
			
?>

<table cellspacing="5"  cellpadding="10">
	<tr> <th >AnimalID</th> <th>Name</th> <th >Description</th> <th >Photo</th> </tr>
  
  
  <?php

if (isset($_SESSION['userlogin'])) {
  $username = $_SESSION['userlogin'];
$usersname=$db->quote($username);
  

}

  $findsid = $db->query("SELECT UserID FROM User WHERE Username= $usersname");
  $f=$findsid->fetch();
  $usersid=$f[0];
	
  // joint query
		$animalist = "SELECT Owns.AnimalID,Name,Description,Photo FROM Animal,Owns WHERE UserID =$usersid";
		$rows=$db->query($animalist);


        //loop through all the returned records and put them into the table cells 
		foreach ($rows as $row) { 
			echo "<tr> <td >" . $row['AnimalID'] . "</td><td >".$row['Name']. "</td><td >" . $row['Description'];
            echo "</td>";
            echo "<td> <img src=".$row['Photo']." alt = 'animal' width = '100' height = '100' </td></tr>";
		
          
		}

		echo "</table> <br/>";
	
} catch (PDOException $ex){
			//this catches the exception when it is thrown
			echo "Sorry, a database error occurred. Please try again.<br> ";
			echo "Error details:". $ex->getMessage();
		}

        
        
        
        
        
?>
  
 
  

</body>



</html>

