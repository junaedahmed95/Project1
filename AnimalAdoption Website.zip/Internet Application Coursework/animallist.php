<html >
<head>
<title>Task 5 Query the student table </title>
</head>
<body>
<form method = "get" action="list_Student.php">
	
	Choose the gender: <br>
	<select name="gender">
		<option value="male" > Male </option>
		<option value="female"> Female </option>
	</select><br/> <br/>
	Choose the year: <br>
	<select name="year">	
	<?php 
	//connect to lab4 database on local server 
	require_once("connectdb.php");
	// Use select to get all years in the student table 
	try{
	$rows=$db->query("SELECT DISTINCT year_enroll FROM student");
	foreach ($rows as $row) { 
	?>
		<option value="<?= $row['year_enroll'] ?>"> <?= $row['year_enroll'] ?> </option>
	<?php 
	} 	?>
	</select><br/> <br/>
	<input type="submit" name="submit" value="Submit" />
	<input type="hidden" name="submitted" value="TRUE" />

</form>

<?php
if (isset($_GET['submitted'])){
	//check the gender input
	if (isset($_GET['gender'])){
		$gender = $db->quote($_GET['gender']);
	}
	else{
		$gender="female";  #default female
	}
	
	//check the year input
	if (isset($_GET['gender'])){
		$year = $_GET['year'];
	}
	else{
		$year=0;  #default 
	}
	echo "<h1> Student Information Table -". htmlspecialchars($gender)." and ". htmlspecialchars($year). " </h1>";
		
?>
	<!-- HTML table to  display  the student records -->
	
	<table cellspacing="0"  cellpadding="5">
	<tr><th>Student_id</th> <th >Course_name</th> <th >First_Name</th> <th >Surname</th><th >Gender</th><th >Year</th><th >Photo</th></tr>
<?php	
	// joint query
		$sqlstr = "SELECT student_id, course_name, first_name, last_name, gender, year_enroll, photo FROM student, course WHERE course.course_id = student.course_id AND gender=$gender AND year_enroll = $year " ;
		
		$rows=$db->query($sqlstr);
	//loop through all the returned records and put them into the table cells 
		foreach ($rows as $row) { 
			echo  "<tr><td >" . $row['student_id'] . "</td><td >" . $row['course_name'] . "</td><td >" . $row['first_name'];
			echo "</td><td >" . $row['last_name'] . "</td><td >" . $row['gender']. "</td><td >" . $row['year_enroll']."</td><td ><img src=". $row['photo']." alt='Smiley face' height='50' width='50'></td></tr>\n";
		}

		echo "</table> <br>";
	}
	} catch (PDOException $ex){
		//this catches the exception when it is thrown
		echo "Sorry, a database error occurred. Please try again.<br> ";
		echo "Error details:". $ex->getMessage();
	}

?>

</body>
</html>