
<?php

if (isset($_POST['submitted'])){
	// error array to  list all error in the form input
	$errors=array();
	//connect to lab4 database on local server 
	require_once("connectdb.php");
	
	//get the form data and do some basic validation  
	if (!empty ($_POST['firstname']))
		$firstname = $_POST['firstname'];
	else{
		$errors[]= "You must input a valid first name! <br>";
	}
	
	if (!empty ($_POST['surname']))
		$surname = $_POST['surname'];
	else{
		$errors[]= "You must input a valid surname! <br>";
	}
	
	$year = intval($_POST['year']);
	if (!$year){
		$errors[]="You must input a valid year! <br>";
	}
} 
if (!empty($errors)){
		echo "<h1> Errors with form submission: </h1> \n <ul>";
		foreach ($errors as $e){
			echo "<li> $e </li>";
		}
		echo "</ul>";
	} else {
try{
			// use the form data to create a insert SQL and  add a student record  
			$sth=$db->prepare("INSERT INTO student(course_id, first_name, last_name, gender, year_enroll, photo) VALUES (?,?,?,?,?,?)");
			$sth->execute(array($course,$firstname,$surname,$gender,$year,$file));
			echo " Well Done, you just add one student record! <br><br>"; 

?>
		<!-- HTML table to  display  all the student records -->
		<table cellspacing="0"  cellpadding="5">
		<tr><th>Student_id</th> <th >Course_id</th> <th >First_Name></th> <th >Surname</th><th >Gender</th><th >Year</th><th >Photo</th></tr>
	<?php


?>