package eReader;

public class chapterList<T extends Comparable<T>> extends LinkedOrderedList{

	public chapterList(){
		super();
	}
	
	public Chapter findByNum(int chapterNum){
		DoubleNode<Chapter> cursor = front;
		while(cursor!=null){
			Chapter c = cursor.getElement();
			if(c.getNum() == chapterNum){
				return c;
			}
			else{
				cursor = cursor.getNext();
			}
		}
		return null;
	}
	
}
