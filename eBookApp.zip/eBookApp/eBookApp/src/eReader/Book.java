package eReader;

import java.util.Scanner;


public class Book<T> {
	
	private String title;
	private String chapterText;
	private Scanner s;
	private chapterList<Chapter> chapterlist;
	private DoubleNode<T> currentChapter;
	
	public Book(String text){
		chapterText = text;
		splitIntoChapters();
		title = "";
	}
	
	private void splitIntoChapters(){
		
		s = new Scanner(chapterText);
		String chaptertitle;
		StringBuilder chaptertext = new StringBuilder();
		while(s.hasNextLine()){
			String line = s.nextLine();
			if(line.contains("CHAPTER")){
				chaptertitle = line;
				while(!line.contains("CHAPTER") && s.hasNext()){
					chaptertext.append(line);
					line = s.nextLine();
				}
				createChapter(chaptertext.toString(), chaptertitle);
				chaptertext.setLength(0);
			}
		}
	}

	public void setTitle(String t){
		title = t;
	}
	
	public void createChapter(String chapter, String title){
		
		title.trim();
		String[] word = title.split(" ");
		int num = convertToNum(word[1]);
		Chapter c = new Chapter(num, title);
		c.setText(chapter);
		
		
	}
	
	public String getChapter(int chapterNum){
		
		Chapter c = chapterlist.findByNum(chapterNum);
		return c.getText();
	}
	
	public String getNextChapter(){
		
		Chapter c = (Chapter) currentChapter.getNext().getElement();
		return c.getText();
	}
	
	public String getPreviousChapter(){
		
		Chapter c = (Chapter) currentChapter.getNext().getElement();
		return c.getText();
	}
	
	public int size(){
		return chapterlist.size();
	}
	
	private int convertToNum(String roman){
		int result = 0;
		String uRoman = roman.toUpperCase(); //case-insensitive
		for(int i = 0;i < uRoman.length() - 1;i++) {//loop over all but the last character
			//if this character has a lower value than the next character
			if (decodeSingle(uRoman.charAt(i)) < decodeSingle(uRoman.charAt(i+1))) {
				//subtract it
				result -= decodeSingle(uRoman.charAt(i));
			} else {
				//add it
				result += decodeSingle(uRoman.charAt(i));
			}
		}
		//decode the last character, which is always added
		result += decodeSingle(uRoman.charAt(uRoman.length()-1));
		return result;
		
	}
	
	private int decodeSingle(char letter){
		switch(letter) {
		case 'M': return 1000;
		case 'D': return 500;
		case 'C': return 100;
		case 'L': return 50;
		case 'X': return 10;
		case 'V': return 5;
		case 'I': return 1;
		default: return 0;
		}
	}
}
