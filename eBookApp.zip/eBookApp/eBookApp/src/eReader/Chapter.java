package eReader;

public class Chapter implements Comparable<Chapter>{
	
	// Number of each indiviual chapter
	private int chapterNum;
	
	// the given title of each chapter
	private String title;
	
	// the text within the chapter
	private String text;
	
	/**constructor a new chapter with chapter number and title values
	 * 
	 * @param chapterNum
	 * @param title
	 */
	public Chapter(int chapterNum, String title){
		
		this.chapterNum = chapterNum;
		this.title = title;
		
	}
	
	/**sets the text of the chapter
	 * 
	 * @param text
	 */
	public void setText(String Text){
		
		this.text = Text;
	}
	
	/**returns the text of the chapter
	 * 
	 * @return text
	 */
	public String getText(){
		
		return text;
	}
	
	public int getNum(){
		return chapterNum;
	}

	@Override
	public int compareTo(Chapter comparedChapter) {
		
		if(getNum() < comparedChapter.getNum()){
			return -1;
		}
		else if(getNum() > comparedChapter.getNum()){
			return 1;
		}
		
		return 0;
	}

}
