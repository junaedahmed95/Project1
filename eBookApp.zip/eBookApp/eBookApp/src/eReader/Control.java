package eReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Control implements Controller {

	private ArrayList<Book> volumes;
	private Scanner s;
	private Book currentBook;
	
	public Control(){
		
		volumes = new ArrayList();
		
		try {
			s = new Scanner(new File("WarAndPeace.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setUp();
		}
	

	private void setUp() {
		
		StringBuilder text = new StringBuilder();
		while(s.hasNextLine()){
			text.append(s.nextLine());
		}
		
		int i = text.indexOf("BOOK", 0);
		int j = text.indexOf("BOOK", i+1);
		int e = text.lastIndexOf("BOOK");
		while(i!=e){
			
			StringBuilder a = new StringBuilder(text.substring(i, j));
			Book b = new Book(a.toString());
			volumes.add(b);
			i = text.indexOf("BOOK", j);
			j = text.indexOf("BOOK", j+1);
		
		}
		
	}


	@Override
	public String getPreviousChapter() {
		String chapter = currentBook.getPreviousChapter();
		return chapter;
	}

	@Override
	public String getNextChapter() {
		String chapter = currentBook.getNextChapter(); 
		return chapter;
	}

	@Override
	public String getChapter(int volumeNumber, int chapterNumber) {
		
		if(volumeNumber > volumes.size()){
			return null;
		}
		else if(chapterNumber > volumes.get(volumeNumber).size()){
			return null;
		}	
			
		Book x = volumes.get(volumeNumber-1);
		String chapterText = x.getChapter(chapterNumber);
		return chapterText;
	}

	@Override
	public String getLinesWithWord(String word) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotalOccurrences(String word) {
		// TODO Auto-generated method stub
		return 0;
	}

}
