package eReader;

import java.util.Iterator;
/**
 * This class models the basic methods for a list ADT using a doubly-linked list.
 * 
 * @author Alan Barnes
 * @version Nov 2009
 *
 * @param <T>
 */
public abstract class DoubleList<T> {
	protected DoubleNode<T> front; // the first node of this doubly linked list
	protected DoubleNode<T> rear; // the last node of this doubly linked list
	protected int count;

	/** Constructor: Creates an empty list. */
	protected DoubleList() {
		rear = null;
		front = null;
		count = 0;
	}

	/** Removes and returns the last element in this list. */
	protected T removeLast() {
		if (isEmpty())
			throw new IllegalStateException("list empty in remove");

		T result = rear.getElement();
		rear = rear.getPrevious();
		count--;
		if (rear == null)
			front = null;
		else
			rear.setNext(null);

		return result;
	}

	/** Removes and returns the first element in this list. */
	protected T removeFirst() {
		if (isEmpty())
			throw new IllegalStateException("list empty in remove");

		T result = front.getElement();
		front = front.getNext();
		count--;
		if (front == null)
			rear = null;
		else
			front.setPrevious(null);

		return result;
	}

	/** Removes the specified node. */
	protected void remove(DoubleNode<T> node) {
		if (node == null)
			throw new IllegalArgumentException("Null pointer passed to remove");

		if (node == front)
			this.removeFirst();
		else if (node == rear)
			this.removeLast();
		else {
			node.getNext().setPrevious(node.getPrevious());
			node.getPrevious().setNext(node.getNext());
			count--;
		}
	}

	/** Adds the specified element to the start of the list. */
	protected void addFirst(T element) {
		DoubleNode<T> node = new DoubleNode<T>(element);
		node.setNext(front); // link new node to rest of list
		front = node; // update front
		if (count == 0) // empty list
			rear = node; // update rear
		else
			// make old front node's previous link point to new node
			front.getNext().setPrevious(node);
		count++;
	}

	/** Adds the specified element to the end of the list. */
	protected void addLast(T element) {
		if (count == 0) { // empty list
			addFirst(element);
		} else {
			DoubleNode<T> node = new DoubleNode<T>(element);
			// link in new node after old rear
			node.setPrevious(rear);
			rear.setNext(node);
			rear = node; // update rear
			count++;
		}
	}

	/** Adds the element after the current node */
	protected void addAfter(DoubleNode<T> current, T element) {
		if (current == null)
			throw new IllegalArgumentException(
					"null node reference in addAfter");

		if (current == rear) {
			addLast(element);
		} else {
			DoubleNode<T> node = new DoubleNode<T>(element);
			node.setNext(current.getNext());
			node.setPrevious(current);
			current.getNext().setPrevious(node);
			current.setNext(node);
			count++;
		}
	}

	/** Adds the element before the current node */
	protected void addBefore(DoubleNode<T> current, T element) {
		if (current == null)
			throw new IllegalArgumentException(
					"null node reference in addBefore");

		if (current == front) {
			addFirst(element);
		} else {
			DoubleNode<T> node = new DoubleNode<T>(element);
			node.setNext(current);
			node.setPrevious(current.getPrevious());
			current.getPrevious().setNext(node);
			current.setPrevious(node);
			count++;
		}
	}

	/** Returns the first node containing the target, or null if it is not found. */
	protected DoubleNode<T> find(T target) {
		DoubleNode<T> cursor = front;

		while (cursor != null) {
			if (target.equals(cursor.getElement())) {
				return cursor;
			} else {
				cursor = cursor.getNext();
			}
		}
		return null;
	}

	/** Returns true if this list contains the element and false otherwise. */
	public boolean contains(T element) {
		return (find(element) != null);
	}

	/** Returns the last node containing the target, or null if it is not found. */
	protected DoubleNode<T> findLast(T target) {
		boolean found = false;
		DoubleNode<T> cursor = rear;
		DoubleNode<T> result = null;

		while (!found && cursor != null) {
			if (target.equals(cursor.getElement())) {
				result = cursor;
				found = true;
			} else {
				cursor = cursor.getPrevious();
			}
		}
		return result;
	}

	/** Returns true if this list is empty and false otherwise. */
	public boolean isEmpty() {
		return (count == 0);
	}

	/** Returns the number of elements currently in this list. */
	public int size() {
		return count;
	}

	/** Sets the list to empty */
	public void clear() {
		front = null;
		rear = null;
		count = 0;
	}

	/** Returns an iterator for the elements in this list. */
	public Iterator<T> iterator() {
		return new DoubleIterator();
	}

	/*
	 * An inner class for modelling an iterator 
	 * for iterating over a doubly-linked-list-based implementation.
	 */
	private class DoubleIterator implements Iterator<T> {
		private DoubleNode<T> cursor; //next node to be returned by iterator
		private DoubleNode<T> node; //node returned by the last call to next

		/** Constructor */
		public DoubleIterator() {
			cursor = front;
			node = null;
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Iterator#hasNext()
		 */
		@Override
		public boolean hasNext() {
			return (cursor != null);
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Iterator#next()
		 */
		@Override
		public T next() {
			if (!hasNext())
				throw new IllegalStateException();
			node = cursor;
			T result = node.getElement();
			cursor = node.getNext();
			return result;
		}

		/** remove the current element in the iteration. */
		public void remove() {
			if (node == null)
				throw new IllegalStateException("no current element to remove");

			if (node == rear) { // last element to be removed
				rear = rear.getPrevious();
				if (rear == null) // list had 1 element and is now empty
					front = null;
				else
					rear.setNext(null);
			} else if (node == front) { // first element to be removed
				// list cannot have only 1 element (when front == rear) here
				// as that case was dealt with above
				front = front.getNext();
				front.setPrevious(null);
			} else { // internal element to be removed
				node.getNext().setPrevious(node.getPrevious());
				node.getPrevious().setNext(node.getNext());
			}
			count--;
			node = null; // ensure remove can only be called once per iteration
		}
	}
}
