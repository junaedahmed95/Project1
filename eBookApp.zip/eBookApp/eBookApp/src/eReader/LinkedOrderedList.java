package eReader;

public class LinkedOrderedList<T extends Comparable<T>> extends DoubleList<T>
		implements OrderedListADT<T> {
	/** Creates an empty list */
	public LinkedOrderedList() {
		super();
	}

	// Adds the specified Comparable element to this list, keeping
	// the elements in sorted order.
	public void add(T element) {
		if (front == null) { // empty list
			addFirst(element);
			return;
		}
		// look for the position where the given element is to be added
		DoubleNode<T> cursor = front;
		while (cursor != null && element.compareTo(cursor.getElement()) > 0) {
			cursor = cursor.getNext();
		}
		if (cursor == null) {
			// element should be added at the end
			addLast(element);
		} else {
			// element should be added BEFORE the cursor node
			addBefore(cursor, element);
		}

	}

	// remove the element. Returns true on success, false otherwise
	public boolean remove(T element) {
		DoubleNode<T> temp = find(element);
		if (temp == null)
			return false;
		super.remove(temp);
		return true;
	}

	// return the first element in the list
	public T first() {
		if (front == null)
			throw new IllegalStateException("no first element");
		return front.getElement();
	}

	// return the last element in the list
	public T last() {
		if (rear == null)
			throw new IllegalStateException("no last element");
		return rear.getElement();
	}

	// remove and return the first element in the list
	public T removeFirst() {
		return super.removeFirst();
	}

	// remove and return the last element in the list
	public T removeLast() {
		return super.removeLast();
	}

}
