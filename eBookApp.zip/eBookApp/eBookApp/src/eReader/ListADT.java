package eReader;

import java.util.Iterator;
/**
 * A list ADT
 * 
 * @author Alan Barnes 
 * @author S H S Wong (modified by)
 * @version 3 Nov 2015 00:17:04
 *
 * @param <T>
 */
public interface ListADT<T> extends Iterable<T> {
	/** 
	 * Removes and returns the first element from this list.
	 * @return	the first last element in the list
	 */
	T removeFirst();

	/** 
	 * Removes and returns the last element from this list. 
	 * @return	the last last element in the list
	 */
	T removeLast();

	/** 
	 * Removes the specified element from this list.
	 * @param	element	a given element tp be removed from the list
	 * @return	true if the given element exists and is removed from the list; false otherwise.
	 */
	boolean remove(T element);

	/** 
	 * Returns a reference to the first element in this list. 
	 * @return	the first element in this list
	 */
	T first();

	/** 
	 * Returns a reference to the last element in this list. 
	 * @return	the last element in this list
	 */
	T last();

	/**
	 * Returns true if this list contains the specified target element. 
	 * @param	target	a given element
	 * @return	true if the given element is stored in this list; false otherwise.
	 */
	boolean contains(T target);

	/** 
	 * Returns true if this list contains no elements. 
	 * @return	true if this list is empty; false otherwise.
	 */
	boolean isEmpty();

	/** 
	 * Returns the number of elements in this list. 
	 * @return	the number of elements in this list.
	 */
	int size();

	/** 
	 * Clears the content of this list.
	 */
	void clear();
	
	/** 
	 * Returns an iterator for the elements in this list.
	 * 
	 * Note that as ListADT extends Iterable, ListADT would have inherited 
	 * the method iterator() from Iterable. Hence, it is not necessary to 
	 * include this method in this interface. 
	 * 
	 * @return	An Iterator for this list.
	 */
	Iterator<T> iterator();
}
