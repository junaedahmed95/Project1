package eReader;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Controller c = new Control();
		TUI t = new TUI(c);
		
		
	}

}
