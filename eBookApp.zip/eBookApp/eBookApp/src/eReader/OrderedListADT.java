package eReader;

public interface OrderedListADT<T extends Comparable<T>> extends ListADT<T> {
	/* Adds the specified element to this list at its proper location */
	void add(T element);
}
