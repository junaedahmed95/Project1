/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author bastinl
 */
public class RegisterUser extends HttpServlet {
    
  private int msgid;
  private String message;
  private Connection connection=null;
  private ResultSet rs = null;
  private Statement st = null;

  // TODO 1 put in your own database name.
  String connectionURL = "localhost;dbname=ahmedj8_db";

    @Override
    public void destroy() {
        
        // TODO 11 Add code here
        
        super.destroy();
    }

    @Override
    public void init() throws ServletException {
        
        super.init();
        
        // TODO 10 Add code here.
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Currently this method does nothing
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int courseID=-1;
        int newStudentID=-1;
        boolean success = false;
        
        // incoming information....
        String username = "";
        String password = "";
        //String email = "";
        //String courseName = "";
        //int enrolmentYear=-1;
        
        /* Make a connection to the database, if it doesn't already exist */
        
        if (connection == null)
        {
            try {

            // Load the database driver
            Class.forName("com.mysql.jdbc.Driver");

            // Get a Connection to the database
            // TODO 2 put in your own password.
            connection = DriverManager.getConnection(connectionURL, "ahmedj8", "whap68gaum");
            
            }catch(Exception e){

                System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
            }
        }
        
        /* Now get the course ID for the student.*/

        // TODO 3 Get the parameters from the request and store them as variables.
        // add code here.....
        
            username = request.getParameter("newUsername");
            password = request.getParameter("newPassword");

        
              
        
        try {
              
            // TODO 4 Create a query which will select the course ID for the course which has been selected.
            String query = "SELECT Username,Password FROM Clients";  // update this line

            Statement stmt = connection.createStatement();
            ResultSet rs1 = stmt.executeQuery(query);

            if (rs1.next()) {  // If there is a row in the ResultSet 
                // TODO 5 Get the course ID from this row. You can use the 
                // getString(fieldIndex) getInt(fieldIndex) or getFloat(fieldIndex) methods
                // BUT REMEMBER that the field index begins at 1, not 0
                // add code here.....

            } 
        }
        catch(SQLException e) {
            System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
        }
        
        /* Now insert the student record into the database */
        try {
            // TODO 6 write a query string which inserts the properties of the student into the 'student' table
            String query2 = "INSERT INTO Clients(Username,Password) VALUES (username,password)";  // update this line

            Statement stmt = connection.createStatement();
            ResultSet rs2 = stmt.executeQuery(query2);

            /* If this query was successful, 
            we should be able to ask for the primary key that was generated */
            
            ResultSet rs3 = stmt.getGeneratedKeys();
            if ( rs3.next() ) {
                // Retrieve the auto generated key(s).
                newStudentID = rs3.getInt(1);
            }

            // check success - return true or false
            if (newStudentID >-1) {
                success = true;
            }
            else {
                success = false;
            }
        }
        catch(SQLException e) {
            System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
            success = false;
         }
        
        /* Now close the database connection */
        try {
            connection.close(); 
            connection = null;
        }catch(Exception e){
                System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
        }
        
        /* Now we know whether or not the student has been successfully inserted into the database
         * We can return an HTML page that informs them of the result, and their new ID.
         */
        //TODO 7 set the content type of the response (text/html) and get a printwriter from it.
        // add code here....
        
        
        if (success) {
            // TODO 8 print out an HTML page that tells the user their new student ID
        }
        else {
            // TODO 9 print out an HTML page that tells the user that the transaction has failed
        }

    }
 

}
