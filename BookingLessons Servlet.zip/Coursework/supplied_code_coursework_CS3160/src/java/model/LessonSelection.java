/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 *
 * @author bastinl
 */
public class LessonSelection  {
    
    private HashMap<String, Lesson> chosenLessons;
    private int ownerID;
    
    private DataSource ds = null;
    
    private ResultSet rs = null;
    private Statement st = null;
    
    private Connection connection = null;

     String connectionURL ="jdbc:mysql://localhost:3306";
    public LessonSelection(int owner) {
        
        chosenLessons = new HashMap<String, Lesson>();
        this.ownerID = owner;

        // You don't need to make any changes to the try/catch code below
        try {
             Class.forName("com.mysql.jdbc.Driver");
       
           //Connection connection = ds.getConnection();
          connection = DriverManager.getConnection(connectionURL, "root","password");
            // Obtain our environment naming context
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            // Look up our data source
            ds = (DataSource)envCtx.lookup("jdbc/LessonDatabase");
        }
            catch(Exception e) {
            System.out.println("Exception message is " + e.getMessage());
        }
        
        // Connect to the database - this is a pooled connection, so you don't need to close it afterwards
        try {

           // Connection connection = ds.getConnection();

            if (connection != null) {
                
                // TODO get the details of any lessons currently selected by this user
                // One way to do this: create a join query which:
                // 1. finds rows in the 'lessons_booked' table which relate to this clientid
                // 2. links 'lessons' to 'lessons_booked' by 'lessonid
                // 3. selects all fields from lessons for these rows
                
                // If you need to test your SQL syntax you can do this in virtualmin
                
                // For each one, instantiate a new Lesson object,
                // and add it to this collection (use 'LessonSelection.addLesson()' )
                
            //creates the queries used to find lessons
            String sqlcheck = "USE MySQL";
          String query= "SELECT * FROM lessons INNER JOIN lessons_booked ON ClientID='" + getOwner() + "'";
        
               Statement stmt =connection.createStatement(); 


                //executes query and stores in result set
                rs = stmt.executeQuery(sqlcheck);
                ResultSet rs1 = stmt.executeQuery(query); 
          
                
                // for every row that the query can find, creates a new lesson object to store values
                while (rs1.next()) {
             
                Lesson ls2= new Lesson(rs1.getString(1),rs1.getTimestamp(2),rs1.getTimestamp(3),rs1.getInt(4),rs1.getString(5));
              
                //adds these lessons to the Lessons selected 
                addLesson(ls2);
              
               chosenLessons.put(rs1.getString(5),ls2);
                
                }
                
          
            
            }
        
        
            }catch(Exception e){

                System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
            }
        
    }

    /**
     * @return the items
     */
    public Set <Entry <String, Lesson>> getItems() {
        return chosenLessons.entrySet();
    }

    public void addLesson(Lesson l) {
       
        Lesson i = new Lesson(l);
        this.chosenLessons.put(l.getId(), i);
       
    }

    public Lesson getLesson(String id){
        return this.chosenLessons.get(id);
    }
    
    public int getNumChosen(){
        return this.chosenLessons.size();
    }

    public int getOwner() {
        return this.ownerID;
    }
    
    public void updateBooking() {
        
        // A tip: here is how you can get the ids of any lessons that are currently selected
        Object[] lessonKeys = chosenLessons.keySet().toArray();
        for (int i=0; i<lessonKeys.length; i++) {
                    
              // Temporary check to see what the current lesson ID is....
              System.out.println("Lesson ID is : " + (String)lessonKeys[i]);
        }
      
        // TODO get a connection to the database as in the method above
        // TODO In the database, delete any existing lessons booked for this user in the table 'lessons_booked'
        // REMEMBER to use executeUpdate, not executeQuery
        // TODO - write and execute a query which, for each selected lesson, will insert into the correct table:
                    // the owner id into the clientid field
                    // the lesson ID into the lessonid field
       

        try {
            
            //creates prepared statement to delete rows already selected by user
             String sqlcheck = "USE MySQL";
            PreparedStatement pstmt= connection.prepareStatement("DELETE * FROM lessons_booked WHERE ClientID='" + getOwner() + "'");
          
            //exceutes statement and updates prepared statement
            Statement stmt =connection.createStatement(); 
            rs = stmt.executeQuery(sqlcheck);
            
              pstmt.executeUpdate(); 
             
             
           //query to select lesson id in lessons table where the owner = the current user logged in
              String query= "SELECT id FROM lessons_booked WHERE ClientID='" + getOwner() + "'";
          
              
                
                rs = stmt.executeQuery(sqlcheck);
                ResultSet rs1 = stmt.executeQuery(query);
                
                while (rs1.next()){
                    
                rs = stmt.executeQuery(sqlcheck);    
          PreparedStatement pstmt2= connection.prepareStatement("INSERT INTO lessons_booked(ClientID,id) VALUES (?,?) WHERE ClientID='" + getOwner() + "'");
          
               
            pstmt2.setInt(1, getOwner());
            pstmt2.setString(2, rs1.getString(1));
            
            
             //ResultSet rs1 = stmt.executeUpdate(pstmt); 
            
                }
                
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(LessonSelection.class.getName()).log(Level.SEVERE, null, ex);
        }
               
    
    }

}
