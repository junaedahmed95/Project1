/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.sql.PreparedStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;

import java.util.logging.Level;
import java.util.logging.Logger;


import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import java.io.PrintWriter;


/**
 *
 * @author bastinl
 */
public class Users  {
  
    private ResultSet rs = null;
    private PreparedStatement pstmt = null;
    DataSource ds = null;
   
     private int isValid;
     
    private String uname;
    private String pass;
    
    private int id;
    
    private Connection connection = null;
     
    String connectionURL ="jdbc:mysql://localhost:3306";
    
    public Users()  {
        
       
      
        // You don't need to make any changes to the try/catch code below
        try {
            
                Class.forName("com.mysql.jdbc.Driver");
       
           //Connection connection = ds.getConnection();
          connection = DriverManager.getConnection(connectionURL, "root","password");
          
            // Obtain our environment naming context
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            // Look up our data source
            ds = (DataSource)envCtx.lookup("jdbc/LessonDatabase");
            //String connectionURL ="jdbc:derby://localhost:1527/sample";
        }
            catch(Exception e) {
            System.out.println("Exception message is " + e.getMessage());
        }
        
    }
    /**
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        // incoming information....
        //uname = request.getParameter("username");
       // pwd = request.getParameter("password");
        uname = "";
        pwd="";
        
    }
    */
    public int isValid(String uname , String pwd) {
      
       
      
      
       try {
              // Load the database driver
                
              

              if (connection != null) {
                
              
               //TODO: implement this method so that if the user does not exist, it returns -1.
               // If the username and password are correct, it should return the 'clientID' value from the database.
                

     
           String sqlcheck = "USE MySQL";
           
           String username = getUname();
           String password = getPass();
          
           
           
           
          String query= "SELECT * FROM Clients WHERE Username='" + username + "' AND Password='"+ password +"';";
               Statement stmt =connection.createStatement(); 


               //stmt.setString(1, getUname());
               //stmt.setString(2, getPass());
                
                rs = stmt.executeQuery(sqlcheck);
                ResultSet rs1 = stmt.executeQuery(query);
                //boolean check = rs.next();
                
                if (rs1.next()) {
                
                return  rs1.getInt(1);
                
               
               
                
                }
                
               
            
                
                
                
            
            }    
           
       }
       
   

        catch(Exception e) {
                    
           System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
            
               return-1;
        } 
      
       return -1;
   }


    
    // TODO (Optional steps 3 and 4) add a user with specified username and password
    public void addUser(String name, String pwd) {
       
      
        //TODO: implement this method so that the specified username and password are inserted into the database.
        //System.out.println(connection);
        
         try {
             
             // Class.forName("com.mysql.jdbc.Driver");
              
             //connection = DriverManager.getConnection(connectionURL, "root","password");
              
              
            if (connection != null) {
                
                String sqlcheck = "USE MySQL";
                Statement stmt =  connection.createStatement();
                
                
               String query = "INSERT INTO Clients (ClientID,Username,Password) VALUES (?,?,?)";
               pstmt = connection.prepareStatement(query);
               
              
              String username = getUname();
               String password = getPass();
               
               rs = stmt.executeQuery(sqlcheck);
                
               
               pstmt.setInt(1,getID());
                pstmt.setString(2,getUname());
                 pstmt.setString(3,getPass());
                 
                 pstmt.executeUpdate();
                  
            
                
                Statement stmt2 =  connection.createStatement();
                
                
                      
                //pstmt.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
                
                if (pstmt.execute()){
                    
                    System.out.println("Success");
                }
                
           
            else {
                System.out.println("NO SQL CONNECTION");
            }
          
            }     
         
         } catch (Exception ex) {
            Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("hmm error ");
        }
         }
    
    
     public void setUname(String uname){
        this.uname = uname;
       
    }
    
    public String getUname(){
        return uname;
    }
    
    
    public void setPass(String pass){
        this.pass = pass;
       
    }
    
    
    public String getPass(){
        return pass;
    }
    
    
    public int getID(){
        
        if (connection != null){
            
            try {
            String sqlcheck = "USE MySQL";
           
           String username = getUname();
           String password = getPass();
          
           
        String query= "SELECT * FROM Clients WHERE Username='" + username + "' AND Password='"+ password +"';";
               
            
                Statement stmt = connection.createStatement();
                
                
                
             


               //stmt.setString(1, getUname());
               //stmt.setString(2, getPass());
                
                rs = stmt.executeQuery(sqlcheck);
                ResultSet rs1 = stmt.executeQuery(query);
                //boolean check = rs.next();
                
                if (rs1.next()) {
                id = rs1.getInt(1);
                return  rs1.getInt(1);
                
                }
        }
               catch (SQLException ex) {
                Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);
            }
                
                }
            return id;
    }
    
    /**
    public void GetUser()
    {
            try 
            {      
                //Db_Connection dbconn=new Db_Connection();
                Connection connection= ds.getConnection();
                
                String sqlString = "SELECT * FROM clients WHERE username = '"+uname+"'";
                Statement myStatement = connection.createStatement();
                ResultSet rs=myStatement.executeQuery(sqlString);

                while(rs.next())
                {
                    
                    uname= rs.getString("username");
                    pass = rs.getString("password");
                }
                
                myStatement.close();
                connection.close();
                
            } catch (SQLException ex) {Logger.getLogger(Users.class.getName()).log(Level.SEVERE, null, ex);} 
            
    }
    /*
/*
      protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Currently this method does nothing
    }
*/
    
    
}
