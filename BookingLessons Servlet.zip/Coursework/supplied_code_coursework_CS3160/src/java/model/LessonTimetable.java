/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import javax.servlet.http.HttpSession;

/**
 *
 * @author bastinl
 */
public class LessonTimetable {

  private Connection connection=null;
  
  private ResultSet rs = null;
  private Statement st = null;
  
  private Map lessons = null;
  
  private DataSource ds = null;
  
  String sqlcheck ="USE MySQL";
    
  String connectionURL ="jdbc:mysql://localhost:3306";

  
    public LessonTimetable() {

        // You don't need to make any changes to the try/catch code below
        
        
        try {
            
                 Class.forName("com.mysql.jdbc.Driver");
       
          connection = DriverManager.getConnection(connectionURL, "root","password");
          
            // Obtain our environment naming context
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            // Look up our data source
            ds = (DataSource)envCtx.lookup("jdbc/LessonDatabase");
        
            if (connection != null) {
                
                // TODO instantiate and populate the 'lessons' HashMap by selecting the relevant infromation from the database
                
                lessons = new HashMap<String, Lesson>();
                
                
                 String query = "SELECT * FROM lessons";
        
                 
          st =connection.createStatement();
          
          ResultSet rs2 = st.executeQuery(sqlcheck);
          rs = st.executeQuery(query);
          
            Lesson j = null;
            int i = 0;
           while (rs.next()) {  // while there is a row in the ResultSet 
                    
               
                   Lesson ls1 = new Lesson (rs.getString(1),rs.getTimestamp(2),rs.getTimestamp(3),rs.getInt(4),rs.getString(5));
                    
                    lessons.put(rs.getString(1),getLessons());
                    
                    //rs.getTimestamp(2).toString();
                    //rs.getTimestamp(3).toString();
                    
                       
           }
                
                
                
                // TODO add code here to retrieve the infromation and create the new Lesson objects
            }
        
        
          }catch(Exception e){

             System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
          }
      
    }
    
   
    /**
     * @return the items
     */
    public Lesson getLesson(String itemID) {
        
        Lesson i = null;
        
        
        
      try { 
          
          
              // Class.forName("com.mysql.jdbc.Driver");
       
      //    connection = DriverManager.getConnection(connectionURL, "root","password");
          
          String query = "SELECT * FROM lessons WHERE id = '" + itemID + "'";
        
          st =connection.createStatement();
          
          ResultSet rs2 = st.executeQuery(sqlcheck);
          rs = st.executeQuery(query);
          
          
           if (rs.next()) {  // If there is a row in the ResultSet 
                    // TODO 3 Create a new Item with the information from this row. You can use the 
                    // getString(fieldIndex) getInt(fieldIndex) and getFloat(fieldIndex) methods
                    // REMEMBER that the field index begins at 1, not 0
                    
                   // String ss = rs.getString(1);
                   
                   
                    i = new Lesson (rs.getString(1),rs.getTimestamp(2),rs.getTimestamp(3),rs.getInt(4),rs.getString(5));
                
                   // rs.getTimestamp(2).toString();
                   // rs.getTimestamp(3).toString();
                 //s   rs.getTimestamp(2).toString();
           }
          
          
      } catch (SQLException ex) {
          Logger.getLogger(LessonTimetable.class.getName()).log(Level.SEVERE, null, ex);
      } 


        
        
        return (Lesson)this.lessons.get(itemID);
        
        
        
        
    }

    public Map getLessons() {
        
        lessons = new HashMap<String,Lesson>();
           
     
           
        try {
            
            
              // Class.forName("com.mysql.jdbc.Driver");
       
          //connection = DriverManager.getConnection(connectionURL, "root","password");
            
          String query = "SELECT * FROM lessons";
          
                st = connection.createStatement();
                
                ResultSet rs2 = st.executeQuery(sqlcheck);
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    
                    // TODO 5 Create a new Item with the data from the current row
                   Lesson lesson =new Lesson (rs.getString(1),rs.getTimestamp(2),rs.getTimestamp(3),rs.getInt(4),rs.getString(5));
                    
                     //rs.getTimestamp(2).toString();
//                   // rs.getTimestamp(3).toString();
                   lessons.put(rs.getString(1), lesson);
                   
                    
                } //end while
                
                 }catch(SQLException e) {
            
            System.out.println("Exception is ;"+e + ": message is " + e.getMessage());
            return null;
        }
        
        
        
        
        
        
        return this.lessons;
        
    }
    
}
