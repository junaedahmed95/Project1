/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import model.LessonTimetable;
import model.Users;
import model.LessonSelection;
import model.Lesson;
import java.io.PrintWriter;

/**
 *
 * @author bastinl
 */
public class Controller extends HttpServlet {

   private Users users;
   //private RegisterUser newUser;
   private LessonTimetable availableLessons;

    public void init() {
         users = new Users();
         availableLessons = new LessonTimetable();
         // TODO Attach the lesson timetable to an appropriate scope
        this.getServletContext().setAttribute("lesson",availableLessons);
        
    }
    
    public void destroy() {
        
        super.destroy();
        
    }

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out = response.getWriter();
        //request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request, response);
       String action = request.getPathInfo();
        RequestDispatcher dispatcher = null;
     
       if (action.equals("/login")){
        
       String name=request.getParameter("username");
        String pwd=request.getParameter("password");
       
        
        
        //users = new Users(uname,pass); 
            
        if (users.isValid(name,pwd) != -1 ){
            
                    HttpSession sessionUser = request.getSession();
                    
                      
                    if (!sessionUser.isNew()){

                    
                   sessionUser.setAttribute("user",users.getUname());
                   sessionUser.getAttribute("user");
                   
                    availableLessons = new LessonTimetable();
                    
                   //sessionUser.getAttribute("lesson");
                   LessonSelection ls = new LessonSelection (users.getID());
                    
                    sessionUser.setAttribute("lessonSelection",ls);
                   
                    
            System.out.println("User Session Name : " + sessionUser.getAttribute("user") + sessionUser.getAttribute("lessonSelection"));
           
                    }
                    
          
                    
                    
            dispatcher = this.getServletContext().getRequestDispatcher("/LessonTimeTableView.jspx");
        }
        
        else {
            
            dispatcher = this.getServletContext().getRequestDispatcher("/login.jsp");
       
        }
        
        
       }
       
       else {
           HttpSession sessionUser = request.getSession(false);
           if (sessionUser==null || (sessionUser.getAttribute("lessonSelection") == null)){
              dispatcher = this.getServletContext().getRequestDispatcher("/login.jsp");
           } else{
               if (action.equals("/chooseLesson")){
                   LessonSelection ls2 = (LessonSelection) sessionUser.getAttribute("lessonSelection");
                  // session.setAttribute("lessonSelection",request.getParameter("itemId"));
                   //session.getAttribute("lessonSelection");
                   
                   String itemID = request.getParameter("itemId");
                   
                   
                  LessonSelection ls = new LessonSelection(users.getID());
                   Lesson lesson1 = ls.getLesson(itemID);
                           
                   ls2.addLesson(lesson1);
                   
                   
                   System.out.println(lesson1);
                   
                   
               
                   dispatcher = this.getServletContext().getRequestDispatcher("/LessonSelectionView.jspx");
              
               } 
               else if (action.equals("/finaliseBooking")){
                   
                   dispatcher = this.getServletContext().getRequestDispatcher("/LessonSelectionView.jspx");
               }else if (action.equals("/logOut")){
                   sessionUser.invalidate();
                   
                   dispatcher = this.getServletContext().getRequestDispatcher("/index.jsp");
               }else {
                   
                   dispatcher = this.getServletContext().getRequestDispatcher("/login.jsp");
               }
           }
       }
       
          
         dispatcher.forward(request,response);
        
         
        
        
       
         
      
        
        
        
         
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       
        /**
        
        String signIn = request.getParameter("username");
        //HttpSession session = request.getSession();
        if (signIn != null ){
            //session.setAttribute("username",signIn);
            
        }
     
        LoginDetail detail = new LoginDetail();
        */
        //users.setUname(request.getParameter("username"));
       //users.setPass(request.getParameter("password"));
        
       //request.setAttribute(, users);
        //String giveuname = response.setAttribute(a,"");
        
        users.setUname(request.getParameter("username"));
        users.setPass(request.getParameter("password"));
         processRequest(request, response);
        
         //users.setUname(response.setContentType(request.getParameter("username")));
        
        //reponse.setContentType(users.setUname(request.getParameter("username")));
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
